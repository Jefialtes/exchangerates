package com.pavel.kruk.exchangerates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExchangeRatesApplicationTests {

	@Test
	void contextLoads() {
	}

}
