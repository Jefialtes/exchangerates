package com.pavel.kruk.exchangerates.service;

import com.pavel.kruk.exchangerates.dto.FixerIoResponseDto;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Transactional
public class FixerIoService {

    @Value("${fixer.apiKey}")
    private String apiKey;

    @Value("${fixer.url}")
    private String url;

    private RestTemplate restTemplate;

    public FixerIoService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public FixerIoResponseDto retrieveExchangeRates(String currencyCode) {
        String apiUrl = url.replace("{API_KEY}", apiKey);

//        Can be use only with paid account on fixer.io
//        url.replace("{API_KEY}", apiKey).replace("{BASE_CURRENCY}", currencyCode);

        FixerIoResponseDto response = restTemplate.getForObject(apiUrl, FixerIoResponseDto.class);
        if (response != null && response.isSuccess()) {
            return response;
        }

        throw new RuntimeException("Failed to retrieve exchange rates from fixer.io");
    }
}