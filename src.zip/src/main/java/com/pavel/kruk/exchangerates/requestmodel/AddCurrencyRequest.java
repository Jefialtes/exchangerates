package com.pavel.kruk.exchangerates.requestmodel;

import lombok.Data;

@Data
public class AddCurrencyRequest {

    private String currencyCode;
}